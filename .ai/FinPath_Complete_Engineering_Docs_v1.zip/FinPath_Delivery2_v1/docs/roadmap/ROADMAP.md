# FinPath delivery roadmap — executable dependency milestones

This is a **complete planning breakdown**, not permission to run all tasks. 53 Step files in `tasks/M00` through `tasks/M09`. Current repo already completed `M00-BOOTSTRAP-000`; do not rerun. The first new task is `M00-01` once user approves the design baseline.

| Milestone | Count | Responsibility | Exit gate |
|---|---:|---|---|
| M00 | 5 | monorepo, build, contracts, auth stub, CI | front/back smoke, mock fail closed |
| M01 | 6 | precise Money, accounts, double-entry ledger | transfer/income/expense invariants |
| M02 | 5 | categories, budgets, period summaries | budget actual equals ledger source |
| M03 | 5 | onboarding, feature visibility, recommendations | reversible user setup, no auth bypass |
| M04 | 6 | simple/composite goals, reservations, 3-goal cap | no asset double counting and atomic quota |
| M05 | 6 | documented scoring & allocation proposals | deterministic and feasible / user-confirmed |
| M06 | 5 | forecasts, scenarios, life-event budget conversions | baseline unchanged by simulations |
| M07 | 5 | asset reporting, FX snapshots, portable data | accurate export/re-import and disclosures |
| M08 | 5 | real auth and tenant security | cross-tenant E2E / production mock disabled |
| M09 | 5 | cloud rollout, integration, loads, recovery, review | explicit secure launch approval |

Execution order default M00 → M01 → M02 → M03 → M04 → M05 → M06 → M07 → M08 → M09. Some disjoint work in M03 and M07 may parallelize after contracts are stable, but default is serial until M04. `tasks/INDEX.md` specifies each explicit prerequisite.

## Release definition

- Internal demo: M00–M03 with synthetic data.
- Planning proof-of-concept: M04–M05 with deterministically tested virtual pools.
- Extended beta: M06–M07 with synthetic records and import/export.
- Public authenticated release with real data: M08+M09 mandatory; secure backup, privacy and monitoring.

## Step stop condition

Implementation stops immediately after one authorized task's acceptance checks. Failure = report blocked, do not automatically skip, weaken invariant or start next task. Parallel activities require separate branches/worktrees and a designated integrator. All operations under Windows PowerShell; git remote verified, never re-clone.

## Tracking

`docs/PROJECT-STATUS.md` in existing repository is authoritative progress record. Add completed task ID, commit hash, passed checks and blockers; do not replace its prior history. `tasks/INDEX.md` records plan metadata, not automatically green checkmarks until implementation verification.
