# FinPath test and verification strategy

## Test pyramid

1. Pure domain unit tests (Vitest): Money, postings, goal statuses, allocation, rounding, timeline boundaries.
2. Repository/transaction tests: Drizzle+D1-compatible SQL, tenant scope, atomic updates, migration reruns, overfund conflicts.
3. HTTP contract tests: Hono validation, typed errors, auth and authorization, idempotent request replay.
4. UI component tests: onboarding skip, feature hiding, keyboard, budget table, confirmation flows.
5. Playwright E2E: successful finances, retries, wrong tenant, export/import, rejected 4th goal, plan confirmation.
6. Release tests: backup restore, quota/load, error redaction and auth hardening.

## Mandatory mathematical properties

- For every posted journal and currency, total debit equals total credit.
- Transfers never change aggregated net worth of owned accounts by themselves.
- Expense counted once regardless of payment method and settlement.
- `totalReserved(account,currency) <= eligibleAvailable(account,currency)` after concurrent attempts.
- `activeTopLevelGoalCount(workspace) <= 3` after concurrent activation.
- Goal preview and scenario are side effect free.
- All calculations deterministic for same inputs and algorithm/version.
- Money and FX preserve units, no naive addition of currencies, boundaries not rounded incorrectly.
- Multi-tenant: no B information readable or mutable by A.

## Quality gates / commands

Commands will be finalized by M00-01/M00-05 and **may not exist yet**: `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm test:integration`, `pnpm test:e2e`, `pnpm build`. Codex must report which actually ran, skip with reason where unavailable and not fabricate green CI.

## Test data

Synthetic only; accounts CAD, CNY, JPY, loan/card, month boundary, leap day, negative/zero, overflow, concurrency, refunds, duplicate API retries, double allocations, scenario modifications, migration rollback. Maintain fixture documentation and deterministic clock.

## Step reviews

Each task's acceptance specifies focused tests; integration gates at M01, M04, M05, M09. No Task marks verified solely because code was generated.
