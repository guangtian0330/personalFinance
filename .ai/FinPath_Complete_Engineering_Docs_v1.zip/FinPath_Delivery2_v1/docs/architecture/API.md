# REST API contracts — proposed `/api/v1`

All payloads validated with Zod schemas in `packages/contracts`. JSON money uses decimal-string `amountMinor`, ISO-4217 `currency`, and `asOf` for dated valuations. Timestamps UTC ISO-8601. Never silently drop unknown sensitive fields. Uniform error:

```json
{"error":{"code":"GOAL_ACTIVE_LIMIT","message":"At most 3 top-level goals may be Active","details":{"limit":3},"requestId":"..."}}
```

HTTP conventions: 400 invalid syntax, 401 unauthenticated, 403 unauthorized (or 404 when hiding existence), 404 absent, 409 conflict/duplicate, 422 valid syntax but invalid domain action, 429 throttled, 500 unexpected with no sensitive stack. API versions via `/api/v1`; no destructive changes without version plan. POST mutation may use `Idempotency-Key` and ETag/version when relevant.

## Identity/profile / feature

| Method / path | Request | Response | Permission |
|---|---|---|---|
| GET `/health` | none | `{status:'ok'}` (no secrets) | public |
| GET `/me` | session | `{user,workspaces}` | authenticated |
| GET/PUT `/preferences` | `{view, featureIds, reportingCurrency,timezone}` | versioned preferences | workspace member |
| POST `/onboarding` | `{householdScope,needs[],nearGoal?}` | `{recommendations[],preferences}` | own workspace |
| GET `/features` | none | manifest + status + rationale | own workspace |

## Ledger and budget

| Method / path | Request | Response |
|---|---|---|
| GET/POST `/accounts` | account create `{name,kind,currency,liquidityClass}` | account list/object |
| GET `/accounts/:id/balance` | asOf? | `{amountMinor,currency,asOf}` |
| GET/POST `/transactions` | create `{kind,occurredAt,postings[],categoryId?,memo?}` | validated journal / paged history |
| POST `/transactions/:id/reverse` | `{reason}` plus expected version | reversal transaction |
| GET/POST `/categories` | category tree/create | list/object |
| GET/POST `/budgets` | budget draft `{periodStart,periodEnd,currency,lines[]}` | budget version |
| POST `/budgets/:id/activate` | `{expectedVersion}` | activated version |
| GET `/budgets/:id/variance` | period and category keys | `{plannedMinor,actualMinor,varianceMinor}` |

Domain postings API in initial version may be used only internally; public UI should offer simple transaction form adapter that produces balanced journal safely. Never expose arbitrary unrestricted posting ability to ordinary users.

## Goals and planning

| Method / path | Request | Response |
|---|---|---|
| GET/POST `/goals` | `{title,type,targetMinor,currency,deadline,components?}` | goal details |
| PATCH `/goals/:id` | `{expectedVersion,patch}` | updated goal with event |
| POST `/goals/:id/transition` | `{to,reason,expectedVersion}` | state change or `GOAL_ACTIVE_LIMIT` |
| GET `/goals/:id/progress` | none | `{targetMinor,reservedMinor,remainingMinor,monthlyNeedMinor?,horizon}` |
| POST `/goal-allocations/preview` | `{sourceAccountId,goalId,amountMinor,action}` | feasibility + reasons |
| POST `/goal-allocations/confirm` | `{previewId,expectedVersion}` | immutable allocation event(s) |
| POST `/funding-plans/preview` | `{goalIds[],forecastHorizon,overrides?}` | `{algorithmId,version,inputsHash,lines[],warnings[]}` |
| POST `/funding-plans/:id/confirm` | `{expectedVersion}` | accepted plan without real bank transfer |
| GET/POST `/scenarios` | scenario assumptions | detached results |

## Reports/import/export

| Method / path | Contract |
|---|---|
| GET `/reports/cash-flow?period=...` | explicit reporting currency, date, FX assumptions |
| GET `/reports/net-worth?asOf=...` | per-currency totals and optional reporting-currency converted totals |
| POST `/imports/csv/preview` | validate row map and proposed posting count; no writes |
| POST `/imports/csv/commit` | checks idempotency and preview hash |
| GET `/exports/backup` | authenticated versioned JSON, no secrets |
| POST `/backups/validate` | verify schema and totals prior to privileged restore |

## Security and pagination

Every private endpoint requires server-derived workspace membership; client-supplied IDs are resource keys, not authorization. Lists use cursor pagination and bounded page size; large exports are authenticated and rate limited. All mutation responses return stable IDs and revisions; no client may unilaterally specify `actorId` or trusted `workspaceId`.

## Version/test contract

`packages/contracts` contains canonical zod validators and TS inference, at least one valid and invalid fixture per endpoint. Client API typed from these definitions; integration tests verify status/error code and cross-workspace rejection. This file specifies behavior, not necessarily final generated schema syntax; Step M00-03 owns the exact types.
